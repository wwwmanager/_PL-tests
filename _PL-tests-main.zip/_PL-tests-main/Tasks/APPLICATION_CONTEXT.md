# APPLICATION CONTEXT

## 1. Общий обзор проекта

- **Название:** Waybill App  
- **Версия:** 1.0.0  
- **Назначение:** управление путевыми листами, транспортом, водителями, бланками и складом для автопредприятий.  
- **Режим работы:** Централизованный (Central Mode) — данные хранятся в PostgreSQL через Backend API.

---

## 2. Технологический стек

### Frontend

- **React** 19 + **TypeScript** + **Vite**
- **TailwindCSS**
- **Формы:** React Hook Form + Zod
- **Тесты:** Vitest + Testing Library + Playwright (E2E)
- **Запуск dev:** `npm run dev` → http://localhost:3000/_PL-tests/

### Backend

- **Express** + **TypeScript** + **TypeORM** (порт 3001)
- **PostgreSQL** — основная БД
- **JWT** аутентификация
- **Структурированное логирование** (Winston)

---

## 3. Архитектура

### 3.1. Frontend

- Авторизация через `/api/auth/login`
- Все данные получаются через API фасады (`services/*Api.ts`)
- httpClient добавляет `Authorization: Bearer <token>` автоматически

### 3.2. Backend

- **Слоистая архитектура:** routes → controllers → services → TypeORM
- **Основные сущности:**
  - Organization, Department
  - User, Role, Permission, UserRole, RolePermission
  - Employee (driver, dispatcher, etc.)
  - Vehicle, FuelCard
  - Waybill, WaybillRoute, WaybillFuel
  - BlankBatch, Blank
  - StockItem, Warehouse, StockMovement
  - AuditLog, RefreshToken
- **Принципы:**
  - Organization isolation: запросы фильтруются по `organizationId` (из JWT)
  - Audit logging для критических операций
  - RBAC на уровне backend

---

## 4. API Endpoints

### 4.1. Авторизация
- `POST /api/auth/login` — вход, возвращает JWT
- `POST /api/auth/refresh` — обновление токена (планируется)

### 4.2. Основные ресурсы
| Ресурс | Endpoint | Описание |
|--------|----------|----------|
| Путевые листы | `/api/waybills` | CRUD, смена статусов |
| Транспорт | `/api/vehicles` | CRUD |
| Сотрудники | `/api/employees` | CRUD, фильтр по типу |
| Бланки | `/api/blanks` | Партии, выдача, материализация |
| Склад | `/api/stock` | Номенклатура, движения |
| Dashboard | `/api/dashboard` | Статистика, истекающие документы |

### 4.3. Авторизация и токены

- `/api/auth/login` → возвращает JWT и данные пользователя
- Токен хранится в localStorage (`auth_token`)
- httpClient добавляет `Authorization: Bearer <token>` к каждому запросу
- Refresh tokens — запланированы (модель `RefreshToken` уже есть)

---

## 5. Текущий статус

### ✅ Завершено (Месяц 1-2)
- Полная миграция всех модулей на Backend API
- Удалён mockApi.ts и Driver Mode
- Аутентификация и RBAC
- Dashboard и отчёты
- Структурированное логирование

### ⏳ В работе (Месяц 3)
- Мониторинг Frontend (Sentry)
- Rate Limiting и Security Headers
- Бэкапы БД

### 📋 Отложено
- Унификация валидации (Zod на backend)
- Виртуализация больших списков

---

## 6. AI Session Rules

### 6.1. При старте сессии

AI обязан:
1. Прочитать `APPLICATION_CONTEXT.md`
2. Прочитать `implementation_plan.md` (если есть)
3. Прочитать `task.md` (если есть)
4. Сообщить пользователю о загруженном контексте

### 6.2. Формат первого сообщения

```
Контекст загружен:
- APPLICATION_CONTEXT.md прочитан
- task.md прочитан

Согласно текущему плану, предлагаю следующие шаги:
1) …
2) …
```

### 6.3. При получении команды

1. Подтвердить загрузку контекста
2. Соотнести команду с планом
3. При необходимости предложить обновление документации

---

=== END OF PROJECT CONTEXT ===