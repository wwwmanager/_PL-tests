// This file is deprecated. All route parsing logic has been moved to services/routeParserService.ts
// Please update your imports to use the new module. This file will be removed in a future version.
export {};
