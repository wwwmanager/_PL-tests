# РЕШЕНИЕ ПРОБЛЕМЫ: Prisma не может скачать движки

## Проблема
Prisma CLI пытается скачать бинарные файлы (query-engine, migration-engine) через интернет, но Windows Firewall блокирует соединение.

## ❌ ЧТО НЕ РАБОТАЕТ
- `npx prisma generate` - зависает на скачивании
- `npx prisma migrate dev` - не может скачать engines
- `npm run prisma:generate` - та же проблема

## ✅ РЕШЕНИЕ (выберите ОДИН из трёх):

---

### Решение 1: Добавить Node.js в исключения Firewall (САМОЕ БЫСТРОЕ)

#### ШАГ 1: Запустить PowerShell от администратора

1. Нажмите `Win + X`
2. Выберите **"Windows PowerShell (Администратор)"** или **"Терминал (администратор)"**
3. Подтвердите UAC запрос

#### ШАГ 2: Выполнить скрипт

Скопируйте и выполните:

```powershell
# Перейти в папку backend
cd C:\_PL-tests\backend

# Запустить скрипт добавления исключения
.\add-node-to-firewall.ps1
```

**Что делает скрипт:**
- Находит путь к `node.exe`
- Создает правило Firewall для исходящих соединений (Outbound)
- Разрешает Node.js подключаться к интернету

#### ШАГ 3: Проверить

После выполнения скрипта:

```powershell
# Проверить, что правило создано
Get-NetFirewallRule -DisplayName "Node.js*" | Format-Table DisplayName, Enabled, Direction, Action

# Попробовать snova
npx prisma --version
```

**Ожидаемый результат:**
```
prisma                  : 5.22.0

@prisma/client          : 5.22.0
...
```

---

### Решение 2: Изменить тип сети на "Частная" (если Solution 1 не помогло)

Windows Firewall менее строг для частных сетей.

#### Через GUI:

1. **Win + I** → открыть Параметры
2. **Сеть и Интернет**
3. **Ethernet** (или Wi-Fi)
4. Нажать на имя сети (например, "Сеть" или "Network")
5. **Тип сетевого профиля**: выбрать **Частный** (Private)
6. Закрыть окно

#### Через PowerShell (от администратора):

```powershell
# Показать текущие профили
Get-NetConnectionProfile

# Найти имя сети (Name), например "Сеть" или "Network"

# Изменить на Private
Set-NetConnectionProfile -Name "Сеть" -NetworkCategory Private

# Проверить
Get-NetConnectionProfile
```

**После этого:**
```powershell
npx prisma generate
```

---

### Решение 3: Ручная загрузка engines (если ничего не помогло)

Если firewall вообще не дает скачать, можно скачать движки вручную.

#### ШАГ 1: Узнать нужную версию engines

```powershell
cd C:\_PL-tests\backend
npm list @prisma/engines
```

Например: `@prisma/engines@7.0.1` (но это проблема, должно быть 5.22.0!)

#### ШАГ 2: Скачать вручную

Перейти на GitHub:
https://github.com/prisma/prisma-engines/releases

Найти релиз для Prisma 5.22.0, скачать:
- `query-engine-windows.dll.node` 
- `schema-engine-windows.exe`
- `migration-engine-windows.exe`

#### ШАГ 3: Положить в правильную папку

```powershell
# Создать папку для engines
$enginesPath = "$env:USERPROFILE\.cache\prisma\engines\5.22.0"
New-Item -ItemType Directory -Force -Path $enginesPath

# Скопировать скачанные файлы туда
# (замените пути на реальные)
Copy-Item "C:\Downloads\query-engine-windows.dll.node" -Destination $enginesPath
Copy-Item "C:\Downloads\schema-engine-windows.exe" -Destination $enginesPath
Copy-Item "C:\Downloads\migration-engine-windows.exe" -Destination $enginesPath
```

#### ШАГ 4: Попробовать снова

```powershell
npx prisma generate --skip-download
```

---

## ⚠️ ВАЖНО: Исправить версии пакетов

У вас в `package.json` несоответствие версий:
- `prisma@5.22.0` ✅
- `@prisma/client@5.22.0` ✅
- `@prisma/engines@7.0.1` ❌ (не должно быть!)

### Исправить:

```powershell
cd C:\_PL-tests\backend

# Удалить неправильную версию
npm uninstall @prisma/engines

# Переустановить правильные версии
npm install --save-exact prisma@5.22.0 @prisma/client@5.22.0
```

---

## 🧪 Проверка успеха

После любого из решений выполните:

```powershell
cd C:\_PL-tests\backend

# 1. Проверить версию (должно работать без зависания)
npx prisma --version

# 2. Сгенерировать Prisma Client
npx prisma generate

# 3. Попробовать миграцию (после настройки .env и PostgreSQL)
npx prisma migrate dev --name test_migration
```

**Успех = нет ошибок и зависаний!**

---

## 🔄 Откат (если что-то сломалось)

### Удалить правило Firewall:

```powershell
Remove-NetFirewallRule -DisplayName "Node.js Outbound"
```

### Вернуть сеть на Public:

```powershell
Set-NetConnectionProfile -Name "Сеть" -NetworkCategory Public
```

---

## Следующие шаги ПОСЛЕ решения проблемы

1. ✅ Убедиться, что `npx prisma --version` работает
2. ✅ Создать `.env` файл с `DATABASE_URL`
3. ✅ Запустить PostgreSQL
4. ✅ Выполнить `npm run prisma:migrate dev --name init`
5. ✅ Выполнить `npm run prisma:seed`
6. ✅ Запустить `npm run dev`

---

## Какое решение выбрать?

| Решение | Когда использовать | Время |
|---------|-------------------|-------|
| **#1: Firewall exception** | Первым делом, самое простое | 2 мин |
| **#2: Private network** | Если #1 не помогло | 1 мин |
| **#3: Manual download** | Если провайдер блокирует GitHub | 10 мин |

**Моя рекомендация: начать с #1.**

---

## Нужна помощь?

Если ни одно решение не помогло, выполните диагностику:

```powershell
# Проверить подключение к интернету
Test-NetConnection -ComputerName github.com -Port 443

# Проверить Firewall rules для Node.js
Get-NetFirewallRule | Where-Object { $_.DisplayName -like "*Node*" }

# Проверить сетевой профиль
Get-NetConnectionProfile
```

Пришлите вывод этих команд для дальнейшей диагностики.
