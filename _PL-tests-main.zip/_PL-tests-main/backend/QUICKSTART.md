# 🚀 Инструкция по быстрому запуску Backend

## Шаг 1: Настройка базы данных PostgreSQL

### Вариант А: Использование локального PostgreSQL

1. Убедитесь, что PostgreSQL установлен и запущен
2. Создайте базу данных:
```sql
CREATE DATABASE waybills;
```

### Вариант Б: Использование Docker

```bash
docker run --name waybills-postgres -e POSTGRES_PASSWORD=postgres -e POSTGRES_DB=waybills -p 5432:5432 -d postgres:15
```

## Шаг 2: Настройка окружения

Скопируйте `.env.template` в `.env`:

```bash
cp .env.template .env
```

Откройте `.env` и настройте параметры:

```env
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/waybills?schema=public"
PORT=3000
JWT_SECRET="ваш_секретный_ключ_минимум_32_символа"
JWT_EXPIRES_IN="15m"
NODE_ENV="development"
```

⚠️ **ВАЖНО**: В production обязательно измените `JWT_SECRET` на надежный случайный ключ!

## Шаг 3: Prisma setup

Сгенерируйте Prisma Client:
```bash
npm run prisma:generate
```

Создайте и примените миграции:
```bash
npm run prisma:migrate
```

При запросе имени миграции введите: `init`

## Шаг 4: Заполнение тестовыми данными

Запустите seed-скрипт:
```bash
npm run prisma:seed
```

Это создаст:
- ✅ Тестовую организацию
- ✅ 2 пользователя:
  - **admin@test.ru** / admin123 (администратор)
  - **dispatcher@test.ru** / dispatcher123 (диспетчер)
- ✅ 2 транспортных средства
- ✅ 2 водителей
- ✅ 2 тестовых путевых листа

## Шаг 5: Запуск сервера

### Режим разработки (с hot-reload):
```bash
npm run dev
```

### Production:
```bash
npm run build
npm start
```

## 🎯 Проверка работы

После запуска откройте в браузере: http://localhost:3000/api/health

Должен вернуться JSON:
```json
{
  "status": "ok",
  "timestamp": "2024-01-..."
}
```

## 🔐 Тестирование авторизации

### C помощью curl:

```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"admin@test.ru\",\"password\":\"admin123\"}"
```

Ответ:
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpX...",
  "user": {
    "id": "...",
    "email": "admin@test.ru",
    "fullName": "Администратор Системы",
    "organizationId": "...",
    "organizationName": "Тестовая организация",
    "role": "admin"
  }
}
```

### Получение списка путевых листов:

Скопируйте `accessToken` из предыдущего ответа и используйте:

```bash
curl http://localhost:3000/api/waybills \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN_HERE"
```

## 🛠️ Полезные команды

```bash
# Открыть Prisma Studio (GUI для БД)
npm run prisma:studio

# Пересоздать БД с нуля
npx prisma migrate reset

# Посмотреть статус миграций
npx prisma migrate status
```

## 🔗 Подключение фронтенда

В файле `.env` фронтенда укажите:
```env
VITE_API_BASE_URL=http://localhost:3000/api
```

## 📝 API Endpoints

Все эндпоинты (кроме `/auth/login` и `/health`) требуют JWT токен в заголовке:
```
Authorization: Bearer <token>
```

### Auth
- `POST /api/auth/login` - Авторизация

### Vehicles
- `GET /api/vehicles` - Список ТС
- `POST /api/vehicles` - Создать ТС
- `GET /api/vehicles/:id` - Получить ТС
- `PUT /api/vehicles/:id` - Обновить ТС
- `DELETE /api/vehicles/:id` - Удалить ТС

### Drivers
- `GET /api/drivers` - Список водителей
- `POST /api/drivers` - Создать водителя
- `GET /api/drivers/:id` - Получить водителя
- `PUT /api/drivers/:id` - Обновить водителя
- `DELETE /api/drivers/:id` - Удалить водителя

### Waybills
- `GET /api/waybills?startDate=...&endDate=...&vehicleId=...&driverId=...&status=...` - Список путевых листов
- `POST /api/waybills` - Создать путевой лист
- `GET /api/waybills/:id` - Получить путевой лист
- `PUT /api/waybills/:id` - Обновить путевой лист
- `DELETE /api/waybills/:id` - Удалить путевой лист
- `PATCH /api/waybills/:id/status` - Изменить статус

### Служебные
- `GET /api/health` - Health check

## 🐛 Решение проблем

### Ошибка подключения к БД
- Проверьте, что PostgreSQL запущен
- Проверьте правильность DATABASE_URL в .env
- Попробуйте подключиться вручную: `psql -U postgres -d waybills`

### JWT ошибки
- Убедитесь, что JWT_SECRET совпадает с тем, который использовался при генерации токена
- Проверьте, что токен не истек

### Prisma ошибки
- Запустите `npm run prisma:generate` после изменений в schema.prisma
- Если миграции не применяются, попробуйте `npx prisma migrate reset`

## 🎉 Готово!

Backend готов к работе. Теперь можно подключать фронтенд или тестировать API через Postman/Insomnia.
