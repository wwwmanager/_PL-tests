/// <reference types="vitest" />

describe('smoke', () => {
  it('works', () => {
    expect(1 + 1).toBe(2);
  });
});
